<?php
return [
    'adminEmail' => 'admin@example.com',
    'password_salt_key' => '!o$n*e(~`'
];
