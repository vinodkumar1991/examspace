<?php
Yii::setAlias('web', 'http://localhost/no1exam/no1exam/admin/');
Yii::setAlias('asset', 'http://localhost/no1exam/no1exam/admin/assets/');
return [];
