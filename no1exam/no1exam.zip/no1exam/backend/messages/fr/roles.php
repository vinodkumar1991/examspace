<?php

return [
    //Roles :: START
    'roles.form.name' => 'prénom',
    'roles.form.code' => 'code',
    'roles.form.description' => 'la description',
    'roles.form.status' => 'statut',
    'roles.form.image' => 'image',
        //Roles :: END
];

