<?php

/**
 * @author Digital Today
 * @access public
 * @ignore The below messages used to give the lable name for textbox [ Telugu ]
 */
return [
    //Devices :: START
    'devices.form.name' => 'పేరు',
    'devices.form.code' => 'కోడ్',
    'devices.form.description' => 'వివరణ',
    'devices.form.status' => 'స్థితి',
    'devices.form.image' => 'చిత్రం',
    'devices.form.select_status' => '--స్థితి ఎంచుకోండి--',
    'devices.form.active' => 'యాక్టివ్',
    'devices.form.inactive' => 'క్రియారహిత',
    'devices.form.submit_btn' => 'సృష్టించు',
    'devices.form.invalid_input' => 'చెల్లని ఇన్పుట్ ఇస్తున్నాము',
        //Devices :: END
];

