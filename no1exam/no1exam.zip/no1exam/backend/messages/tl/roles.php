<?php

return [
    //Roles :: START
    'roles.form.name' => 'పేరు',
    'roles.form.code' => 'కోడ్',
    'roles.form.description' => 'వివరణ',
    'roles.form.status' => 'స్థితి',
    'roles.form.image' => 'చిత్రం',
        //Roles :: END
];

