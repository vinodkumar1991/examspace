<?php

return [
    //Roles :: START
    'roles.form.name' => 'Name',
    'roles.form.code' => 'Code',
    'roles.form.description' => 'Description',
    'roles.form.status' => 'Status',
    'roles.form.image' => 'Image',
    'roles.form.is_required' => '{alias} is required.',
        //Roles :: END
];

