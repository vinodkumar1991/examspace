<?php

/**
 * @author Digital Today
 * @access public
 * @ignore The below messages used to give the lable name for textbox [ English ]
 */
return [
    //Devices :: START
    'devices.form.name' => 'Name',
    'devices.form.code' => 'Code',
    'devices.form.description' => 'Description',
    'devices.form.status' => 'Status',
    'devices.form.image' => 'Image',
    'devices.form.select_status' => '--Select Status--',
    'devices.form.active' => 'Active',
    'devices.form.inactive' => 'Inactive',
    'devices.form.submit_btn' => 'Create',
    'devices.form.invalid_input' => 'Invalid Input Is Given',
        //Devices :: END
];




