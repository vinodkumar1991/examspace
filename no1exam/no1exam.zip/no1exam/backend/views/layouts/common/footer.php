<footer class="main-footer">
	<strong>Copyright &copy; 2017 <a href="#">no1exam.com</a>.
	</strong> All rights reserved.

</footer>