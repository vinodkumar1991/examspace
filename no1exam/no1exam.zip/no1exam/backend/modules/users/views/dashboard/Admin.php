<?php
echo 'I am in admin dashboard';