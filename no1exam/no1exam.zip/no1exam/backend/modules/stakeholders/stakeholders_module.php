<?php
namespace app\modules\stakeholders;

use yii\base\Module;

class stakeholders_module extends Module
{

    public $controllerNamespace = 'app\modules\stakeholders\controllers';

    public function init()
    {
        parent::init();
    }
}
