<?php
namespace app\modules\notification;

use yii\base\Module;

class notification_module extends Module
{

    public $controllerNamespace = 'app\modules\notification\controllers';

    public function init()
    {
        parent::init();
    }
}
