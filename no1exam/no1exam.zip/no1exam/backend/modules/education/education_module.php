<?php
namespace app\modules\education;

use yii\base\Module;

class education_module extends Module
{

    public $controllerNamespace = 'app\modules\education\controllers';

    public function init()
    {
        parent::init();
    }
}
