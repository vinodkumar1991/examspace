<?php
namespace app\modules\locations;

use yii\base\Module;

class locations_module extends Module
{

    public $controllerNamespace = 'app\modules\locations\controllers';

    public function init()
    {
        parent::init();
    }
}
