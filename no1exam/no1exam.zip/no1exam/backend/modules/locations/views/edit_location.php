<div class="modal-body">
	<form class="form-horizontal" action="" method="post"
		enctype="multipart/form-data">
		<div class="form-group">
			<label class="col-md-3">Location Type</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Country</option>
					<option>City</option>
					<option>District</option>
					<option>Mondal</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">Country</label>
			<div class="col-md-6">
				<input type="text" class="form-control" name="" id="" value="" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">Country</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Country</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">State</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Andhrapradesh</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">District</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Country</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">City</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Hyderabad</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">Mondal</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Hyderabad</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">Village</label>
			<div class="col-md-6">
				<select class="form-control">
					<option>Ameerpet</option>
				</select>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-3">Edit village</label>
			<div class="col-md-6">
				<input type="text" class="form-control">
			</div>
		</div>
		<div class="form-group text-center">
			<input type="button" class="btn btn-primary" value="Submit">
		</div>
	</form>
</div>