<?php
namespace app\modules\quiz;

use yii\base\Module;

class quiz_module extends Module
{

    public $controllerNamespace = 'app\modules\quiz\controllers';

    public function init()
    {
        parent::init();
    }
}
